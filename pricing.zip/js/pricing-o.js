var pricing_loader_view,
	pricing_items_view,
	pricing_items_suppliers_table_view;


var PRICING_ITEMS = [],
	PRICING_SUPPLIERS = [],
	SELECTED_ITEMS = {};


var PricingLoaderView = Backbone.View.extend({
	el: '#contents',
	render: function () {
		$("#home-tabs a").removeClass('home-tab-active');
		$("#pricing-tab").addClass('home-tab-active');

		var template = _.template($("#pricing-items-loader-view").html());
		this.$el.html(template); 
		$("#pricing-items-loader").css('width', ($("#pricing-tab").position().left) + 100);
		
		Backbone.ajax({
			type: 'GET',
			url: 'controller.php',
			data: { command: 'GetItemsforPricing' },
			dataType: 'json',
			success: function (response) {
				$("#pricing-loader").hide();
				
				if(response.error == 0) {
					PRICING_ITEMS = response.data; 
					pricing_items_view = new PricingItemsView({ 
																	items: response.data                
																});
					pricing_items_view.render();
				}
			}
		});
	}
});



var PricingItemsView = Backbone.View.extend({
	el: '#contents',
	render: function () {
		var template = _.template(
									$("#pricing-items-view").html(), {
										categories_items: this.options['items']
								});
		this.$el.html(template); 
	},
	events: {
		'click .pricing-item-category-item': 'itemSelectedUnselected', 
		'click #send-selected-items': 'sendSelectedItems', 
	},
	itemSelectedUnselected: function (e) {
		if($(e.currentTarget).hasClass('pricing-item-category-item-chosen')) {
			$(e.currentTarget).attr('data-chosen', 0);
			$(e.currentTarget).removeClass('pricing-item-category-item-chosen');

			if($('.pricing-item-category-item-chosen').length == 0) {
				$("#send-selected-items").hide();
			}
		}
		else {
			$(e.currentTarget).attr('data-chosen', 1);
			$(e.currentTarget).addClass('pricing-item-category-item-chosen');

			$("#send-selected-items").show();
		}
	},
	sendSelectedItems: function () {
		if($("#send-selected-items").attr('data-in-progress') == '1') {
			return;
		}

		var selected_items = [];
		$(".pricing-item-category-item-chosen").each(function () {
			SELECTED_ITEMS[$(this).attr('data-item-id')] = PRICING_ITEMS[$(this).attr('data-category-id')][$(this).attr('data-item-id')];
			selected_items.push($(this).attr('data-item-id'));
		});
		PRICING_ITEMS = []; 

		$("#send-selected-items").text('Processing ..').css('opacity', '0.5').attr('data-in-progress', '1');
		Backbone.ajax({
			type: 'GET',
			url: 'controller.php',
			data: { command: 'GetSuppliersforPricing', selected_items: selected_items },
			dataType: 'json',
			success: function (response) {
				$("#send-selected-items").text('Edit Prices').css('opacity', '1').attr('data-in-progress', '0');

				if(response.error == 0) {
					pricing_items_suppliers_table_view = new PricingItemsSuppliersTableView({ 
																	suppliers: response.data.suppliers,
																	prices: response.data.prices                 
																});
					pricing_items_suppliers_table_view.render();
				}
			}
		});
	}
});



var PricingItemsSuppliersTableView = Backbone.View.extend({
	el: '#contents',
	render: function () {
		var template = _.template(
								$("#pricing-items-suppliers-table-view").html(), {
									suppliers: this.options['suppliers'],
									prices: this.options['prices'],
								});
		this.$el.html(template); 
	},
	events: {
		'keyup #pricing-items-suppliers-table td input[type="text"]': 'textboxKeyup',
		'click #pricing-items-suppliers-table td input[type="checkbox"]': 'checkItems', 
		'click #pricing-table-save-prices': 'saveEditedPrices', 
		'click #prepare-excel': 'prepareExcel',
		'click #create-excel': 'createExcel', 
	},
	textboxKeyup: function (e) { 
		if($(e.currentTarget).val() != $(e.currentTarget).attr('defaultValue')) {
			$(e.currentTarget).addClass('edited-price');
		}
		else {
			$(e.currentTarget).removeClass('edited-price');	
		}

		if($(".edited-price").length == 0) {
			$("#pricing-table-save-prices").hide();
		}
		else {
			$("#pricing-table-save-prices").show();
		}
	},
	checkItems: function () {
		$("#excel-prices-container").hide();
		$("#create-excel").hide();

		if($("#pricing-items-suppliers-table td input[type='checkbox']:checked").length == 0) {
			$("#prepare-excel").hide();
		}
		else {
			$("#prepare-excel").show();
		}
	},
	saveEditedPrices: function () {
		if($("#pricing-table-save-prices").attr('data-in-progress') == '1') {
			return;
		}

		var edited_prices = [],
			edited_price = {},
			parent_row;

		$(".pricing-item-row").has(".edited-price").each(function () {
			edited_price = {};
			parent_row = $(this);
			edited_price.item_id = parent_row.attr('data-item-id');
			edited_price.item_variety_id = parent_row.attr('data-item-variety-id');
			edited_price.unit_id = parent_row.attr('data-unit-id');

			if(parent_row.find(".pricing-table-price-1 input[type='text']").hasClass('edited-price')) {
				edited_price.price_1 = parent_row.find(".pricing-table-price-1 input[type='text']").val();
			}

			if(parent_row.find(".pricing-table-price-2 input[type='text']").hasClass('edited-price')) {
				edited_price.price_2 = parent_row.find(".pricing-table-price-2 input[type='text']").val();
			}

			if(parent_row.find(".pricing-table-price-3 input[type='text']").hasClass('edited-price')) {
				edited_price.price_3 = parent_row.find(".pricing-table-price-3 input[type='text']").val();
			}

			edited_prices.push(edited_price);
		});

		$("#pricing-table-save-prices").text('Saving ..').css('opacity', '0.5').attr('data-in-progress', '1');
		Backbone.ajax({
			type: 'POST',
			url: 'controller.php',
			data: { command: 'SaveAalgroPrices', edited_prices: edited_prices },
			dataType: 'json',
			success: function (response) {
				$("#pricing-table-save-prices").text('Save').css('opacity', '1').attr('data-in-progress', '0');

				if(response.error == 0) {
					$("#pricing-table-save-prices").hide();

					$(".edited-price").removeClass('edited-price');
					
					for(var i in response.data.prices) {
						for(var j in response.data.prices[i]) {
							for(var k in response.data.prices[i][j]) {
								if('price_1' in response.data.prices[i][j][k]) {
									$("#pricing-item-row-" + i + '-' + j + '-' + k).find(".pricing-table-price-1 input[type='text']").val(response.data.prices[i][j][k]['price_1']);
									$("#pricing-item-row-" + i + '-' + j + '-' + k).find(".pricing-table-price-1 input[type='text']").attr('defaultValue', response.data.prices[i][j][k]['price_1']);
								}

								if('price_2' in response.data.prices[i][j][k]) {
									$("#pricing-item-row-" + i + '-' + j + '-' + k).find(".pricing-table-price-2 input[type='text']").val(response.data.prices[i][j][k]['price_2']);
									$("#pricing-item-row-" + i + '-' + j + '-' + k).find(".pricing-table-price-2 input[type='text']").attr('defaultValue', response.data.prices[i][j][k]['price_2']);
								}

								if('price_3' in response.data.prices[i][j][k]) {
									$("#pricing-item-row-" + i + '-' + j + '-' + k).find(".pricing-table-price-3 input[type='text']").val(response.data.prices[i][j][k]['price_3']);
									$("#pricing-item-row-" + i + '-' + j + '-' + k).find(".pricing-table-price-3 input[type='text']").attr('defaultValue', response.data.prices[i][j][k]['price_3']);
								}
							}
						}
					}
				}
			}
		});
	},
	prepareExcel: function () {
		$("#prepare-excel").hide();

		$("#excel-prices-container").show();
		$("#create-excel").show();
	}
});